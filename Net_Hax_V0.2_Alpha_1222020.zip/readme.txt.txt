1. This program is Windows only or whatever OS support Windows Batch and Windows CMDs. 
2. High chance there will be no further updates to this program.
3. No, I will not make a linux version but like why would any linux user want to use this. 
4. Yes, the commands are just renamed Windows command like ipconfig /all and netstat -a are netinfo and trafview.
5. Why did I make this? Because I really like batch and can't make a good C++ program so I decided to use this as motivation 
to make new updates for one project. Who knows! Thsi might even be a C++ program one day whereas I will make it a linux program.




Current Compatabilty: 
Literally any Windows OS that is post-Windows 2000. Might even work on win 95-98 not 100% though. 
Currently this is just a compiled batch file so its only Windows. But I think there is batch plugins for MacOS
and linux but I know nothing about that sort of emulation. 


If you for some reason needed to contact me of all people in existance. 

My PRIVATE email is redjinx120@gmail.com. 